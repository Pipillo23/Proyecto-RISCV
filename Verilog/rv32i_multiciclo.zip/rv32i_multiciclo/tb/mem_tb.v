`timescale 1ns/1ps
// Testbench de mem (memoria única)
// Objetivo : carga del hex, lectura, sw, sb por carril, recorte de dirección y volcado.
// Estímulos: lee palabra 0; sw en 0xFFFFFFF0; sb en 0xFFFFFFEF (carril 3); llama dump.
// Esperado : palabra 0 = fe010113 (primera línea del hex); 0xFFFFFFF0 = 0000C7DF;
//            0xFFFFFFEC = 62000000; archivo volcado_mem_tb.txt con 2 líneas de datos.
// NOTA: cambiar HEX por la ruta COMPLETA del programa.hex (barras normales).
module mem_tb;
    parameter HEX = "programa.hex";
    reg clk = 0, we, mb; reg [31:0] addr, wd; wire [31:0] rd; integer errors = 0;
    mem #(.MEM_FILE(HEX)) dut (.clk(clk), .MemWrite(we), .MemByte(mb), .Addr(addr), .WD(wd), .RD(rd));
    always #5 clk = ~clk;

    task store(input [31:0] a, input [31:0] d, input byte_en);
        begin addr = a; wd = d; mb = byte_en; we = 1; @(posedge clk); #1; we = 0; end
    endtask
    task check_eq(input [31:0] a, input [31:0] exp);
        begin addr = a; #1; if (rd !== exp) begin errors = errors + 1;
              $display("FAIL addr=%h rd=%h (esperado %h)", a, rd, exp); end end
    endtask

    initial begin
        we = 0; mb = 0; addr = 0; wd = 0; #12;
        check_eq(32'h0, 32'hfe010113);                 // carga del hex
        store(32'hFFFFFFF0, 32'h0000C7DF, 0);        // sw r
        store(32'hFFFFFFEF, 32'h00000062, 1);        // sb a (carril 3)
        check_eq(32'hFFFFFFF0, 32'h0000C7DF);
        check_eq(32'hFFFFFFEC, 32'h62000000);
        check_eq(32'h0, 32'hfe010113);                 // el programa no se pisó
        dut.dump("volcado_mem_tb.txt");
        if (errors == 0) $display("mem_tb: PASS"); else $display("mem_tb: FAIL (%0d)", errors);
        $finish;
    end
endmodule
