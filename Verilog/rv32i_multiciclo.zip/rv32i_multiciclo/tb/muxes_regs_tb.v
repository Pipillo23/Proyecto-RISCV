`timescale 1ns/1ps
// Testbench de mux2, mux3, mux4, reg_en y reg_simple
// Objetivo : cada mux elige la entrada correcta; reg_en solo carga con en=1 y se
//            reinicia con rst; reg_simple copia en cada flanco.
// Estímulos: entradas distintas (1,2,3,4) y todas las combinaciones de select.
// Esperado : mux devuelve la entrada indicada; reg_en conserva su valor con en=0.
module muxes_regs_tb;
    reg [31:0] d0 = 1, d1 = 2, d2 = 3, d3 = 4; reg [1:0] s; reg s1; reg clk = 0, rst, en;
    wire [31:0] y2, y3, y4, qe, qs; integer errors = 0;
    mux2 m2 (.d0(d0), .d1(d1), .s(s1), .y(y2));
    mux3 m3 (.d0(d0), .d1(d1), .d2(d2), .s(s), .y(y3));
    mux4 m4 (.d0(d0), .d1(d1), .d2(d2), .d3(d3), .s(s), .y(y4));
    reg_en     re (.clk(clk), .rst(rst), .en(en), .d(d1), .q(qe));
    reg_simple rs (.clk(clk), .d(d2), .q(qs));
    always #5 clk = ~clk;

    task check_eq(input [31:0] got, input [31:0] exp, input [127:0] n);
        begin if (got !== exp) begin errors = errors + 1; $display("FAIL %0s: %h (esp %h)", n, got, exp); end end
    endtask
    initial begin
        rst = 1; en = 0; s = 0; s1 = 0; @(posedge clk); #1; rst = 0;
        check_eq(qe, 0, "reg_en reset");
        s1 = 0; #1; check_eq(y2, 1, "mux2 s=0"); s1 = 1; #1; check_eq(y2, 2, "mux2 s=1");
        s = 0; #1; check_eq(y3, 1, "mux3 0"); check_eq(y4, 1, "mux4 0");
        s = 1; #1; check_eq(y3, 2, "mux3 1"); check_eq(y4, 2, "mux4 1");
        s = 2; #1; check_eq(y3, 3, "mux3 2"); check_eq(y4, 3, "mux4 2");
        s = 3; #1; check_eq(y4, 4, "mux4 3");
        en = 0; @(posedge clk); #1; check_eq(qe, 0, "reg_en en=0 conserva");
        en = 1; @(posedge clk); #1; check_eq(qe, 2, "reg_en en=1 carga");
        check_eq(qs, 3, "reg_simple copia");
        if (errors == 0) $display("muxes_regs_tb: PASS"); else $display("muxes_regs_tb: FAIL (%0d)", errors);
        $finish;
    end
endmodule
