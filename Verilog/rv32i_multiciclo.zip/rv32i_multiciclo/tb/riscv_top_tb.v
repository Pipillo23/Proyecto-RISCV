`timescale 1ns/1ps
// Testbench de riscv_top (prueba del programa completo del profesor)
// Objetivo : ejecutar el programa y comparar el estado final con lo esperado;
//            volcar la memoria de datos a archivo.
// Estímulos: Reset 2 ciclos y luego solo Clock; se detiene cuando 'ret' vuelve al PC = 0.
// Esperado : r = 0xC7DF (0xFFFFFFF0), b = 2 (0xFFFFFFE8), i = 2 (0xFFFFFFE4),
//            a = 0x62 en el byte 3 de la palabra 0xFFFFFFEC, 58 instrucciones,
//            unos 240 ciclos. Volcado en volcado_memoria.txt.
// NOTA: cambiar HEX por la ruta COMPLETA del programa.hex (barras normales).
module riscv_top_tb;
    parameter HEX = "programa.hex";
    reg Clock = 0, Reset = 1;
    integer cycles = 0, instrs = 0, errors = 0;
    reg done = 0;
    riscv_top #(.MEM_FILE(HEX)) dut (.Clock(Clock), .Reset(Reset));
    always #5 Clock = ~Clock;

    // Índice de palabra de una dirección (misma regla de recorte que mem, WORDS = 256)
    function [7:0] widx(input [31:0] a);
        widx = a[9:2];
    endfunction

    task check_eq(input [31:0] addr, input [31:0] exp);
        reg [31:0] got;
        begin
            got = dut.u_mem.ram[widx(addr)];
            if (got !== exp) begin
                errors = errors + 1;
                $display("FAIL @%h = %h (esperado %h)", addr, got, exp);
            end
        end
    endtask

    initial begin
        repeat (2) @(posedge Clock);
        #1 Reset = 0;
        // Se muestrea en el flanco de bajada, cuando los valores ya están estables
        while (!done) begin
            @(negedge Clock);
            if (dut.u_ctrl.state == 4'd0) begin
                if (dut.pc == 32'd0 && instrs > 0) done = 1;   // ret volvió a 0: fin
                else instrs = instrs + 1;
            end
            if (!done) cycles = cycles + 1;
            if (cycles > 2000) begin
                $display("FAIL: el programa no terminó");
                errors = errors + 1;
                done = 1;
            end
        end

        check_eq(32'hFFFFFFF0, 32'h0000C7DF);   // r
        check_eq(32'hFFFFFFE8, 32'h00000002);   // b
        check_eq(32'hFFFFFFE4, 32'h00000002);   // i
        check_eq(32'hFFFFFFEC, 32'h62000000);   // a (sb en el byte 3)
        if (instrs !== 58) begin errors = errors + 1; $display("FAIL instrucciones = %0d (esperado 58)", instrs); end
        $display("Instrucciones: %0d   Ciclos: %0d", instrs, cycles);

        dut.u_mem.dump("volcado_memoria.txt");   // se crea en la carpeta de simulación
        if (errors == 0) $display("riscv_top_tb: PASS"); else $display("riscv_top_tb: FAIL (%0d)", errors);
        $finish;
    end
endmodule
