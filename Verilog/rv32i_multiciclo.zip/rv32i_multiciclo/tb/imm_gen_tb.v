`timescale 1ns/1ps
// Testbench de imm_gen
// Objetivo : verificar los 5 tipos de inmediato con instrucciones reales del programa.
// Estímulos: instrucciones del hex del profesor con su ImmSrc.
// Esperado : addi sp,sp,-32 (I)=FFFFFFE0 | sw ra,28(sp) (S)=0000001C |
//            bge a0,a1,0x4c en 0x44 (B)=00000008 | j 0x9c en 0x48 (J)=00000054 |
//            jal en 0x98 hacia 0x3c (J)=FFFFFFA4 | lui a1,0xc (U)=0000C000.
module imm_gen_tb;
    reg [31:0] i; reg [2:0] s; wire [31:0] imm; integer errors = 0;
    imm_gen dut (.instr(i), .ImmSrc(s), .ImmExt(imm));
    task check(input [31:0] ins, input [2:0] src, input [31:0] exp);
        begin i = ins; s = src; #1;
              if (imm !== exp) begin errors = errors + 1;
                  $display("FAIL instr=%h src=%b imm=%h (esperado %h)", ins, src, imm, exp); end end
    endtask
    initial begin
        check(32'hfe010113, 3'b000, 32'hFFFFFFE0);  // I
        check(32'h00112e23, 3'b001, 32'h0000001C);  // S
        check(32'h00b55463, 3'b010, 32'h00000008);  // B
        check(32'h0540006f, 3'b011, 32'h00000054);  // J hacia adelante
        check(32'hfa5ff06f, 3'b011, 32'hFFFFFFA4);  // J hacia atrás
        check(32'h0000c5b7, 3'b100, 32'h0000C000);  // U
        if (errors == 0) $display("imm_gen_tb: PASS"); else $display("imm_gen_tb: FAIL (%0d)", errors);
        $finish;
    end
endmodule
