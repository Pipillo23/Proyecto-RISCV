`timescale 1ns/1ps
// Testbench de control_unit
// Objetivo : verificar la secuencia de estados por tipo de instrucción, señales clave
//            y la condición de salto (Taken) de beq, bne, blt y bge.
// Estímulos: opcodes lw, sw, addi, lui, jal, jalr, beq con Zero/Lt variados.
// Esperado : lw S0,S1,S2,S3,S4 (5 ciclos) | sw S0,S1,S2,S5 | addi S0,S1,S6,S7 |
//            lui S0,S1,S11,S7 | jal S0,S1,S9,S7 | jalr S0,S1,S10,S9,S7 |
//            branch S0,S1,S8; PCWrite en S8 según tabla de saltos.
module control_unit_tb;
    reg clk = 0, rst; reg [6:0] op; reg [2:0] f3; reg z, lt;
    wire pcw, irw, rw, mw, adr, mb; wire [1:0] sa, sb, rs; wire [2:0] ac, imm;
    integer errors = 0;
    control_unit dut (.clk(clk), .rst(rst), .opcode(op), .funct3(f3), .Zero(z), .Lt(lt),
        .PCWrite(pcw), .IRWrite(irw), .RegWrite(rw), .MemWrite(mw), .AdrSrc(adr), .MemByte(mb),
        .ALUSrcA(sa), .ALUSrcB(sb), .ResultSrc(rs), .ALUControl(ac), .ImmSrc(imm));
    always #5 clk = ~clk;

    task st(input [3:0] exp);           // revisa el estado actual y avanza un ciclo
        begin #1; if (dut.state !== exp) begin errors = errors + 1;
              $display("FAIL estado=%0d (esperado %0d) opcode=%b", dut.state, exp, op); end
              @(posedge clk); end
    endtask
    task restart; begin rst = 1; @(posedge clk); #1; rst = 0; end endtask

    task branch_case(input [2:0] F3, input Z, input L, input expTaken);
        begin f3 = F3; z = Z; lt = L; #1;
              if (pcw !== expTaken) begin errors = errors + 1;
                  $display("FAIL branch f3=%b z=%b lt=%b PCWrite=%b (esp %b)", F3, Z, L, pcw, expTaken); end end
    endtask

    initial begin
        z = 0; lt = 0; f3 = 3'b010; op = 7'b0000011; restart;
        // lw: 5 estados
        st(0); st(1); st(2); st(3); st(4);
        // sw (funct3=010) y sb (funct3=000)
        op = 7'b0100011; f3 = 3'b010; restart; st(0); st(1); st(2);
        st(5);
        f3 = 3'b000; #1; if (mb !== 1'b1) begin errors = errors + 1; $display("FAIL MemByte sb"); end
        f3 = 3'b010; #1; if (mb !== 1'b0) begin errors = errors + 1; $display("FAIL MemByte sw"); end
        // addi
        op = 7'b0010011; f3 = 3'b000; restart; st(0); st(1); st(6); st(7);
        // lui
        op = 7'b0110111; restart; st(0); st(1); st(11); st(7);
        // jal
        op = 7'b1101111; restart; st(0); st(1); st(9); st(7);
        // jalr
        op = 7'b1100111; restart; st(0); st(1); st(10); st(9); st(7);
        // branch: llegar a S8 y probar Taken
        op = 7'b1100011; restart; st(0); st(1); #1;
        if (dut.state !== 4'd8) begin errors = errors + 1; $display("FAIL no llegó a S8"); end
        branch_case(3'b000, 1, 0, 1); branch_case(3'b000, 0, 0, 0);   // beq
        branch_case(3'b001, 0, 0, 1); branch_case(3'b001, 1, 0, 0);   // bne
        branch_case(3'b100, 0, 1, 1); branch_case(3'b100, 0, 0, 0);   // blt
        branch_case(3'b101, 0, 0, 1); branch_case(3'b101, 0, 1, 0);   // bge
        // S0 activa Fetch
        f3 = 0; restart; #1;
        if (!(irw && pcw && !adr && sb == 2'b10 && rs == 2'b10 && sa == 2'b00)) begin
            errors = errors + 1; $display("FAIL señales de S0"); end
        if (errors == 0) $display("control_unit_tb: PASS"); else $display("control_unit_tb: FAIL (%0d)", errors);
        $finish;
    end
endmodule
