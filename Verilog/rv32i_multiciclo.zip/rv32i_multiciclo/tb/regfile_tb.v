`timescale 1ns/1ps
// Testbench de regfile
// Objetivo : escritura en flanco, lectura de 2 puertos, x0 siempre 0, WE3=0 no escribe.
// Estímulos: escribe x5 y x6, intenta escribir x0, intenta escribir con WE3=0.
// Esperado : x5=DEADBEEF, x6=12345678, x0=0, x7 sin cambio (0).
module regfile_tb;
    reg clk = 0, we; reg [4:0] a1, a2, a3; reg [31:0] wd;
    wire [31:0] rd1, rd2; integer errors = 0;
    regfile dut (.clk(clk), .WE3(we), .A1(a1), .A2(a2), .A3(a3), .WD3(wd), .RD1(rd1), .RD2(rd2));
    always #5 clk = ~clk;

    task write(input [4:0] r, input [31:0] v, input en);
        begin we = en; a3 = r; wd = v; @(posedge clk); #1; we = 0; end
    endtask
    task check_eq(input [31:0] got, input [31:0] exp, input [127:0] name);
        begin if (got !== exp) begin errors = errors + 1;
              $display("FAIL %0s: %h (esperado %h)", name, got, exp); end end
    endtask

    initial begin
        we = 0; a1 = 0; a2 = 0; a3 = 0; wd = 0; #12;
        write(5'd5, 32'hDEADBEEF, 1);
        write(5'd6, 32'h12345678, 1);
        write(5'd0, 32'hFFFFFFFF, 1);   // debe ignorarse
        write(5'd7, 32'hAAAAAAAA, 0);   // WE3 = 0: no escribe
        a1 = 5'd5; a2 = 5'd6; #1;
        check_eq(rd1, 32'hDEADBEEF, "rd1 x5"); check_eq(rd2, 32'h12345678, "rd2 x6");
        a1 = 5'd0; a2 = 5'd7; #1;
        check_eq(rd1, 32'h0, "x0"); check_eq(rd2, 32'h0, "x7 sin escribir");
        if (errors == 0) $display("regfile_tb: PASS"); else $display("regfile_tb: FAIL (%0d)", errors);
        $finish;
    end
endmodule
