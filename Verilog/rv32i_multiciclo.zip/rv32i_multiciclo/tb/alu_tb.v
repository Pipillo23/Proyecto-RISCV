`timescale 1ns/1ps
// Testbench de alu
// Objetivo : verificar suma, resta, AND, SLL y las banderas Zero y Lt (con signo).
// Estímulos: pares (a, b, ALUControl) de la tabla de abajo.
// Esperado : ver columnas 'exp' en cada llamada a check(). Imprime PASS/FAIL.
module alu_tb;
    reg  [31:0] a, b; reg [2:0] c;
    wire [31:0] r; wire z, lt;
    integer errors = 0;
    alu dut (.a(a), .b(b), .ALUControl(c), .Result(r), .Zero(z), .Lt(lt));

    task check(input [31:0] A, input [31:0] B, input [2:0] C,
               input [31:0] expR, input expZ, input expLt, input chkFlags);
        begin
            a = A; b = B; c = C; #1;
            if (r !== expR || (chkFlags && (z !== expZ || lt !== expLt))) begin
                errors = errors + 1;
                $display("FAIL a=%h b=%h c=%b -> r=%h z=%b lt=%b (esperado r=%h z=%b lt=%b)",
                         A, B, C, r, z, lt, expR, expZ, expLt);
            end
        end
    endtask

    initial begin
        check(32'd5,        32'd3,  3'b000, 32'd8,        0, 0, 0);  // suma
        check(32'd7,        32'd7,  3'b001, 32'd0,        1, 0, 1);  // resta igual: Zero=1
        check(32'hFFFFFFE0, 32'd2,  3'b001, 32'hFFFFFFDE, 0, 1, 1);  // negativo < 2: Lt=1 (con signo)
        check(32'd2,        32'hFFFFFFE0, 3'b001, 32'h00000022, 0, 0, 1); // 2 < negativo: Lt=0
        check(32'h62,       32'h0F, 3'b010, 32'h02,       0, 0, 0);  // AND: 0x62 & 0x0F = 0x02
        check(32'h42,       32'h0F, 3'b010, 32'h02,       0, 0, 0);  // AND: 66 & 15 = 2 (b del programa)
        check(32'h21,       32'd1,  3'b110, 32'h42,       0, 0, 0);  // SLL: 33<<1 = 66
        check(32'h1,        32'd32, 3'b110, 32'h1,        0, 0, 0);  // SLL usa solo b[4:0]: 32 -> 0
        check(32'd9,        32'd9,  3'b111, 32'd0,        0, 0, 0);  // control no usado -> 0
        if (errors == 0) $display("alu_tb: PASS"); else $display("alu_tb: FAIL (%0d errores)", errors);
        $finish;
    end
endmodule
