// =============================================================================
// Módulo : riscv_top
// Función: Microarquitectura RV32I multiciclo completa. Conecta la unidad de
//          control con la ruta de datos (PC, memoria única, IR, OldPC, banco de
//          registros, A, B, ALU, ALUOut, Data y los multiplexores).
// Entradas : Clock, Reset   (las ÚNICAS dos, según el enunciado)
// Salidas  : ninguna
// Parámetro: MEM_FILE ruta completa del programa en hexadecimal ($readmemh).
// Por qué existe: es el módulo que se evalúa; en la evaluación solo cambia el
//          contenido del archivo de la memoria.
// =============================================================================
module riscv_top #(
    parameter MEM_FILE = "programa.hex"      // CAMBIAR por ruta completa: C:/ruta/programa.hex
) (
    input Clock,
    input Reset
);

    // ---------------- Señales de control ----------------
    wire        PCWrite, IRWrite, RegWrite, MemWrite, AdrSrc, MemByte;
    wire [1:0]  ALUSrcA, ALUSrcB, ResultSrc;
    wire [2:0]  ALUControl, ImmSrc;
    wire        Zero, Lt;

    // ---------------- Datos ----------------
    wire [31:0] pc, oldpc, ir, mem_addr, mem_rd, data;
    wire [31:0] rd1, rd2, a, b, immext;
    wire [31:0] srca, srcb, aluresult, aluout, result;

    // ---------------- Unidad de control ----------------
    control_unit u_ctrl (
        .clk(Clock), .rst(Reset),
        .opcode(ir[6:0]), .funct3(ir[14:12]), .Zero(Zero), .Lt(Lt),
        .PCWrite(PCWrite), .IRWrite(IRWrite), .RegWrite(RegWrite),
        .MemWrite(MemWrite), .AdrSrc(AdrSrc), .MemByte(MemByte),
        .ALUSrcA(ALUSrcA), .ALUSrcB(ALUSrcB), .ResultSrc(ResultSrc),
        .ALUControl(ALUControl), .ImmSrc(ImmSrc)
    );

    // ---------------- PC, IR, OldPC (con enable) ----------------
    // El bit 0 del PC siempre es 0 (jalr deja ese bit en 0)
    reg_en u_pc    (.clk(Clock), .rst(Reset), .en(PCWrite), .d({result[31:1], 1'b0}), .q(pc));
    reg_en u_ir    (.clk(Clock), .rst(Reset), .en(IRWrite), .d(mem_rd), .q(ir));
    reg_en u_oldpc (.clk(Clock), .rst(Reset), .en(IRWrite), .d(pc),     .q(oldpc));

    // ---------------- Memoria única + mux de dirección ----------------
    mux2 u_adrmux (.d0(pc), .d1(aluout), .s(AdrSrc), .y(mem_addr));
    mem #(.MEM_FILE(MEM_FILE)) u_mem (
        .clk(Clock), .MemWrite(MemWrite), .MemByte(MemByte),
        .Addr(mem_addr), .WD(b), .RD(mem_rd)
    );
    reg_simple u_data (.clk(Clock), .d(mem_rd), .q(data));

    // ---------------- Banco de registros, A y B ----------------
    regfile u_rf (
        .clk(Clock), .WE3(RegWrite),
        .A1(ir[19:15]), .A2(ir[24:20]), .A3(ir[11:7]),
        .WD3(result), .RD1(rd1), .RD2(rd2)
    );
    reg_simple u_a (.clk(Clock), .d(rd1), .q(a));
    reg_simple u_b (.clk(Clock), .d(rd2), .q(b));

    // ---------------- Generador de inmediatos ----------------
    imm_gen u_imm (.instr(ir), .ImmSrc(ImmSrc), .ImmExt(immext));

    // ---------------- ALU y sus multiplexores ----------------
    mux4 u_srca (.d0(pc), .d1(oldpc), .d2(a), .d3(32'b0), .s(ALUSrcA), .y(srca));
    mux3 u_srcb (.d0(b), .d1(immext), .d2(32'd4), .s(ALUSrcB), .y(srcb));
    alu  u_alu  (.a(srca), .b(srcb), .ALUControl(ALUControl),
                 .Result(aluresult), .Zero(Zero), .Lt(Lt));
    reg_simple u_aluout (.clk(Clock), .d(aluresult), .q(aluout));

    // ---------------- Mux de resultado (a PC y a WD3) ----------------
    mux3 u_result (.d0(aluout), .d1(data), .d2(aluresult), .s(ResultSrc), .y(result));

endmodule
