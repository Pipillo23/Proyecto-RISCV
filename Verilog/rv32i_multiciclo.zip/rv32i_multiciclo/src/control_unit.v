// =============================================================================
// Módulo : control_unit
// Función: Unidad de control del multiciclo = FSM de 12 estados (S0..S11) +
//          decodificadores. Cada estado dura UN ciclo y activa solo las señales
//          que necesita; el opcode decide el camino después de S1 (Decode).
// Entradas : clk, rst
//            opcode (IR[6:0]), funct3 (IR[14:12])
//            Zero, Lt  (banderas de la ALU, usadas por los saltos)
// Salidas  : PCWrite, IRWrite, RegWrite, MemWrite, AdrSrc, MemByte
//            ALUSrcA[1:0], ALUSrcB[1:0], ResultSrc[1:0], ALUControl[2:0], ImmSrc[2:0]
// Por qué existe: en multiciclo una instrucción se reparte en varios ciclos y
//          alguien debe decir qué hace la ruta de datos en cada uno.
//
// Decodificadores (todos combinacionales):
//   ImmSrc    : solo con el opcode (la FSM no necesita estados por tipo de imm).
//   MemByte   : funct3 == 000 (sb).
//   ALUControl: ALUOp 00 suma | 01 resta | 10 según funct3 (000 suma, 111 AND, 001 SLL).
//   Taken     : funct3[2] ? funct3[0] ^ Lt : funct3[0] ^ Zero
//               beq 000 -> Zero | bne 001 -> ~Zero | blt 100 -> Lt | bge 101 -> ~Lt
//   PCWrite   : PCUpdate | (Branch & Taken)
// =============================================================================
module control_unit (
    input        clk,
    input        rst,
    input  [6:0] opcode,
    input  [2:0] funct3,
    input        Zero,
    input        Lt,
    output       PCWrite,
    output reg   IRWrite,
    output reg   RegWrite,
    output reg   MemWrite,
    output reg   AdrSrc,
    output       MemByte,
    output reg [1:0] ALUSrcA,
    output reg [1:0] ALUSrcB,
    output reg [1:0] ResultSrc,
    output reg [2:0] ALUControl,
    output reg [2:0] ImmSrc
);

    // ---- Opcodes usados por el programa del profesor ----
    localparam OP_LW     = 7'b0000011;
    localparam OP_ITYPE  = 7'b0010011;   // addi, andi, slli
    localparam OP_SW     = 7'b0100011;   // sw, sb
    localparam OP_LUI    = 7'b0110111;
    localparam OP_BRANCH = 7'b1100011;   // beq, bne, blt, bge
    localparam OP_JALR   = 7'b1100111;
    localparam OP_JAL    = 7'b1101111;

    // ---- Estados ----
    localparam S0_FETCH   = 4'd0;
    localparam S1_DECODE  = 4'd1;
    localparam S2_MEMADR  = 4'd2;
    localparam S3_MEMREAD = 4'd3;
    localparam S4_MEMWB   = 4'd4;
    localparam S5_MEMWR   = 4'd5;
    localparam S6_EXECI   = 4'd6;
    localparam S7_ALUWB   = 4'd7;
    localparam S8_BRANCH  = 4'd8;
    localparam S9_ENLACE  = 4'd9;
    localparam S10_JALRADR= 4'd10;
    localparam S11_LUI    = 4'd11;

    reg [3:0] state, next_state;

    // ---- Registro de estado ----
    always @(posedge clk) begin
        if (rst) state <= S0_FETCH;
        else     state <= next_state;
    end

    // ---- Lógica de siguiente estado ----
    always @(*) begin
        case (state)
            S0_FETCH:  next_state = S1_DECODE;
            S1_DECODE: case (opcode)
                           OP_LW, OP_SW: next_state = S2_MEMADR;
                           OP_ITYPE:     next_state = S6_EXECI;
                           OP_LUI:       next_state = S11_LUI;
                           OP_BRANCH:    next_state = S8_BRANCH;
                           OP_JAL:       next_state = S9_ENLACE;
                           OP_JALR:      next_state = S10_JALRADR;
                           default:      next_state = S0_FETCH;
                       endcase
            S2_MEMADR:  next_state = (opcode == OP_LW) ? S3_MEMREAD : S5_MEMWR;
            S3_MEMREAD: next_state = S4_MEMWB;
            S4_MEMWB:   next_state = S0_FETCH;
            S5_MEMWR:   next_state = S0_FETCH;
            S6_EXECI:   next_state = S7_ALUWB;
            S7_ALUWB:   next_state = S0_FETCH;
            S8_BRANCH:  next_state = S0_FETCH;
            S9_ENLACE:  next_state = S7_ALUWB;
            S10_JALRADR:next_state = S9_ENLACE;
            S11_LUI:    next_state = S7_ALUWB;
            default:    next_state = S0_FETCH;
        endcase
    end

    // ---- Salidas por estado (X de la tabla = 0) ----
    reg       PCUpdate, Branch;
    reg [1:0] ALUOp;

    always @(*) begin
        // Valores por defecto: todo apagado
        PCUpdate = 0; Branch = 0; IRWrite = 0; RegWrite = 0; MemWrite = 0;
        AdrSrc = 0; ALUSrcA = 2'b00; ALUSrcB = 2'b00; ALUOp = 2'b00; ResultSrc = 2'b00;

        case (state)
            S0_FETCH:   begin  // IR<-Mem[PC]; OldPC<-PC; PC<-PC+4
                AdrSrc = 0; IRWrite = 1; PCUpdate = 1;
                ALUSrcA = 2'b00; ALUSrcB = 2'b10; ALUOp = 2'b00; ResultSrc = 2'b10;
            end
            S1_DECODE:  begin  // A<-rs1; B<-rs2; ALUOut<-OldPC+Imm
                ALUSrcA = 2'b01; ALUSrcB = 2'b01; ALUOp = 2'b00;
            end
            S2_MEMADR:  begin  // ALUOut<-A+Imm
                ALUSrcA = 2'b10; ALUSrcB = 2'b01; ALUOp = 2'b00;
            end
            S3_MEMREAD: begin  // Data<-Mem[ALUOut]
                AdrSrc = 1;
            end
            S4_MEMWB:   begin  // rd<-Data
                RegWrite = 1; ResultSrc = 2'b01;
            end
            S5_MEMWR:   begin  // Mem[ALUOut]<-B
                AdrSrc = 1; MemWrite = 1;
            end
            S6_EXECI:   begin  // ALUOut<-A op Imm
                ALUSrcA = 2'b10; ALUSrcB = 2'b01; ALUOp = 2'b10;
            end
            S7_ALUWB:   begin  // rd<-ALUOut
                RegWrite = 1; ResultSrc = 2'b00;
            end
            S8_BRANCH:  begin  // A-B; si se cumple PC<-ALUOut (destino calculado en S1)
                Branch = 1; ALUSrcA = 2'b10; ALUSrcB = 2'b00; ALUOp = 2'b01; ResultSrc = 2'b00;
            end
            S9_ENLACE:  begin  // PC<-ALUOut; ALUOut<-OldPC+4
                PCUpdate = 1; ResultSrc = 2'b00;
                ALUSrcA = 2'b01; ALUSrcB = 2'b10; ALUOp = 2'b00;
            end
            S10_JALRADR:begin  // ALUOut<-A+Imm
                ALUSrcA = 2'b10; ALUSrcB = 2'b01; ALUOp = 2'b00;
            end
            S11_LUI:    begin  // ALUOut<-0+Imm
                ALUSrcA = 2'b11; ALUSrcB = 2'b01; ALUOp = 2'b00;
            end
            default: ;
        endcase
    end

    // ---- Decodificador de ImmSrc (solo opcode) ----
    always @(*) begin
        case (opcode)
            OP_ITYPE, OP_LW, OP_JALR: ImmSrc = 3'b000;  // I
            OP_SW:                    ImmSrc = 3'b001;  // S
            OP_BRANCH:                ImmSrc = 3'b010;  // B
            OP_JAL:                   ImmSrc = 3'b011;  // J
            OP_LUI:                   ImmSrc = 3'b100;  // U
            default:                  ImmSrc = 3'b000;
        endcase
    end

    // ---- Decodificador de la ALU ----
    always @(*) begin
        case (ALUOp)
            2'b00:   ALUControl = 3'b000;                 // suma
            2'b01:   ALUControl = 3'b001;                 // resta
            2'b10:   case (funct3)                        // según funct3
                         3'b000:  ALUControl = 3'b000;    // addi
                         3'b111:  ALUControl = 3'b010;    // andi
                         3'b001:  ALUControl = 3'b110;    // slli
                         default: ALUControl = 3'b000;
                     endcase
            default: ALUControl = 3'b000;
        endcase
    end

    // ---- MemByte: sb tiene funct3 = 000 (sw tiene 010) ----
    assign MemByte = (funct3 == 3'b000);

    // ---- Saltos condicionales ----
    wire Taken = funct3[2] ? (funct3[0] ^ Lt) : (funct3[0] ^ Zero);
    assign PCWrite = PCUpdate | (Branch & Taken);

endmodule
