// =============================================================================
// Módulo : mem
// Función: MEMORIA ÚNICA de instrucciones y datos (arquitectura multiciclo).
// Entradas : clk
//            Addr     (32 bits) dirección; el mux AdrSrc (0 = PC, 1 = ALUOut)
//                     se hace en el módulo principal, antes de esta entrada
//            WD       (32 bits) dato a escribir (viene del registro B)
//            MemWrite escribe en el flanco de subida
//            MemByte  1 = escribe solo 1 byte (sb), 0 = palabra completa (sw)
// Salida   : RD (32 bits) palabra leída (combinacional); alimenta IR y Data
// Parámetros: MEM_FILE ruta COMPLETA del .hex con barras normales (C:/ruta/programa.hex)
//             WORDS    palabras de memoria (potencia de 2)
// Por qué existe: es lo que marca la teoría del multiciclo: una sola memoria,
//          y en cada ciclo se decide si se lee una instrucción o un dato.
//
// Mapeo de direcciones: se usan solo los bits [log2(WORDS)+1 : 2] de Addr
//          (se "recorta" la dirección). Así la pila en 0xFFFFFFxx cae dentro de
//          la memoria sin chocar con el programa (0x00..0xAC).
//          Con WORDS = 256: 0xFFFFFFE0 -> palabra 248; el programa ocupa 0..43.
//
// Volcado: la tarea dump escribe "Dirección de Memoria / Valor en hexadecimal"
//          con la dirección ORIGINAL (completa) de cada palabra escrita por
//          sw/sb durante la ejecución.
// =============================================================================
module mem #(
    parameter MEM_FILE = "programa.hex",
    parameter WORDS    = 256
) (
    input         clk,
    input         MemWrite,
    input         MemByte,
    input  [31:0] Addr,
    input  [31:0] WD,
    output [31:0] RD
);

    localparam AW = $clog2(WORDS);

    reg [31:0] ram       [0:WORDS-1];
    reg [31:0] last_addr [0:WORDS-1];   // dirección completa de la última escritura
    reg        written   [0:WORDS-1];   // 1 si alguna vez se escribió con sw/sb

    wire [AW-1:0] idx = Addr[AW+1:2];

    integer i;
    initial begin
        for (i = 0; i < WORDS; i = i + 1) begin
            ram[i]       = 32'b0;
            last_addr[i] = 32'b0;
            written[i]   = 1'b0;
        end
        $readmemh(MEM_FILE, ram);
    end

    // Lectura asíncrona: siempre entrega la palabra completa
    assign RD = ram[idx];

    // Escritura síncrona
    always @(posedge clk) begin
        if (MemWrite) begin
            written[idx]   <= 1'b1;
            last_addr[idx] <= Addr;
            if (MemByte) begin
                // sb: el byte se escribe en el carril que indica Addr[1:0]
                case (Addr[1:0])
                    2'b00: ram[idx][7:0]   <= WD[7:0];
                    2'b01: ram[idx][15:8]  <= WD[7:0];
                    2'b10: ram[idx][23:16] <= WD[7:0];
                    2'b11: ram[idx][31:24] <= WD[7:0];
                endcase
            end else begin
                ram[idx] <= WD;                      // sw
            end
        end
    end

    // Volcado de la memoria de datos a archivo
    task dump;
        input [1023:0] filename;
        integer f, k;
        begin
            f = $fopen(filename, "w");
            $fdisplay(f, "Direccion de Memoria / Valor en hexadecimal");
            for (k = 0; k < WORDS; k = k + 1)
                if (written[k])
                    $fdisplay(f, "%08h %08h", {last_addr[k][31:2], 2'b00}, ram[k]);
            $fclose(f);
        end
    endtask

endmodule
