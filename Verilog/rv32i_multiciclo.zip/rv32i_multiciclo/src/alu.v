// =============================================================================
// Módulo : alu
// Función: Unidad aritmético-lógica ÚNICA y compartida del multiciclo.
//          Suma, resta, AND y desplazamiento a la izquierda (SLL).
// Entradas : a, b (32 bits)      operandos (salen de los mux SrcA y SrcB)
//            ALUControl (3 bits) 000 suma | 001 resta | 010 AND | 110 SLL
// Salidas  : Result (32 bits)    resultado de la operación
//            Zero               1 si Result == 0   (lo usan beq y bne)
//            Lt                 1 si a < b CON SIGNO (lo usan blt y bge)
// Por qué existe: una sola ALU hace PC+4 (Fetch), destinos de salto (Decode),
//          direcciones de lw/sw/sb, addi/andi/slli y la resta de los saltos.
//          Por eso es el módulo que más se reutiliza entre estados.
// =============================================================================
module alu (
    input      [31:0] a,
    input      [31:0] b,
    input      [2:0]  ALUControl,
    output reg [31:0] Result,
    output            Zero,
    output            Lt
);

    always @(*) begin
        case (ALUControl)
            3'b000:  Result = a + b;              // addi, direcciones, PC+4, destinos
            3'b001:  Result = a - b;              // comparación de los saltos
            3'b010:  Result = a & b;              // andi
            3'b110:  Result = a << b[4:0];        // slli (shamt = 5 bits: 0..31)
            default: Result = 32'b0;              // evita latches
        endcase
    end

    // Zero: A == B cuando la ALU resta (A - B == 0)
    assign Zero = (Result == 32'b0);

    // Lt: se compara a y b directamente, con signo. No se usa el bit de signo
    // de (a - b) porque ese bit falla cuando hay overflow en la resta.
    assign Lt = ($signed(a) < $signed(b));

endmodule
