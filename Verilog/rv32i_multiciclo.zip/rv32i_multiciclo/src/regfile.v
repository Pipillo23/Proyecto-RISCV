// =============================================================================
// Módulo : regfile
// Función: Banco de 32 registros de 32 bits (x0..x31). x0 siempre vale 0.
// Entradas : clk, WE3 (RegWrite), A1 (rs1), A2 (rs2), A3 (rd), WD3 (dato)
// Salidas  : RD1, RD2  (lectura combinacional de rs1 y rs2)
// Por qué existe: guarda las variables y registros del programa (sp, s0, a0...).
//          Escritura en flanco de subida; lectura asíncrona.
// =============================================================================
module regfile (
    input         clk,
    input         WE3,
    input  [4:0]  A1,
    input  [4:0]  A2,
    input  [4:0]  A3,
    input  [31:0] WD3,
    output [31:0] RD1,
    output [31:0] RD2
);

    reg [31:0] regs [0:31];
    integer i;

    // Todos en 0 al inicio de la simulación (sp = 0 al arrancar, como dice el handoff)
    initial begin
        for (i = 0; i < 32; i = i + 1) regs[i] = 32'b0;
    end

    // Escritura: nunca en x0 (por ejemplo 'j' es jal x0 y 'ret' es jalr x0)
    always @(posedge clk) begin
        if (WE3 && (A3 != 5'b0)) regs[A3] <= WD3;
    end

    // Lectura: x0 devuelve 0 siempre
    assign RD1 = (A1 == 5'b0) ? 32'b0 : regs[A1];
    assign RD2 = (A2 == 5'b0) ? 32'b0 : regs[A2];

endmodule
