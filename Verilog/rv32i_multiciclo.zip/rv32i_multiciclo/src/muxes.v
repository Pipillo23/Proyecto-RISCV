// =============================================================================
// Módulos : mux2, mux3, mux4  (multiplexores de 32 bits por defecto)
// Función : eligen una entre 2, 3 o 4 fuentes según la señal de control s.
// Usos    : mux2 -> AdrSrc (0 PC, 1 ALUOut)
//           mux4 -> SrcA   (00 PC, 01 OldPC, 10 A, 11 cero)
//           mux3 -> SrcB   (00 B, 01 ImmExt, 10 constante 4)
//           mux3 -> Result (00 ALUOut, 01 Data, 10 ALUResult directo)
// Por qué existen: la ALU es única, así que sus entradas cambian de fuente
//          en cada estado.
// =============================================================================
module mux2 #(parameter W = 32) (
    input  [W-1:0] d0, d1,
    input          s,
    output [W-1:0] y
);
    assign y = s ? d1 : d0;
endmodule

module mux3 #(parameter W = 32) (
    input  [W-1:0] d0, d1, d2,
    input  [1:0]   s,
    output reg [W-1:0] y
);
    always @(*) begin
        case (s)
            2'b00:   y = d0;
            2'b01:   y = d1;
            2'b10:   y = d2;
            default: y = {W{1'b0}};
        endcase
    end
endmodule

module mux4 #(parameter W = 32) (
    input  [W-1:0] d0, d1, d2, d3,
    input  [1:0]   s,
    output reg [W-1:0] y
);
    always @(*) begin
        case (s)
            2'b00: y = d0;
            2'b01: y = d1;
            2'b10: y = d2;
            2'b11: y = d3;
        endcase
    end
endmodule
