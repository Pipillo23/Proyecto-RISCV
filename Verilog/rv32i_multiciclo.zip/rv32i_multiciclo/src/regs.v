// =============================================================================
// Módulos : reg_en y reg_simple
// reg_en    : registro con enable (para PC, IR y OldPC). Solo carga si en = 1.
//             Entradas clk, rst (síncrono), en, d. Salida q.
// reg_simple: registro sin enable (para A, B, ALUOut y Data): copia su entrada
//             en CADA flanco. Guardan el resultado de un ciclo para el siguiente.
// Por qué existen: en el multiciclo los valores intermedios de una instrucción
//          deben sobrevivir entre estados; estos registros lo hacen posible.
// =============================================================================
module reg_en #(parameter W = 32, parameter RST_VAL = 0) (
    input              clk,
    input              rst,
    input              en,
    input      [W-1:0] d,
    output reg [W-1:0] q
);
    always @(posedge clk) begin
        if (rst)     q <= RST_VAL;
        else if (en) q <= d;
    end
endmodule

module reg_simple #(parameter W = 32) (
    input              clk,
    input      [W-1:0] d,
    output reg [W-1:0] q
);
    initial q = {W{1'b0}};
    always @(posedge clk) q <= d;
endmodule
