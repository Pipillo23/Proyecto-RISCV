# RV32I multiciclo (MT-7003) - Avance 2

Carpetas: `src/` (diseño), `tb/` (testbenches), `programs/programa.hex` (programa del profesor, 44 palabras).

## Vivado
1. Agregar todos los `src/*.v` como Design Sources y los `tb/*.v` como Simulation Sources.
2. En cada testbench que lee el hex, cambiar `HEX` (o el parámetro `MEM_FILE` de `riscv_top`) por la
   ruta COMPLETA con barras normales: `C:/ruta/programa.hex`.
3. Simular cada tb por separado (Set as Top): alu_tb, regfile_tb, imm_gen_tb, mem_tb,
   muxes_regs_tb, control_unit_tb y al final riscv_top_tb. Cada uno imprime PASS o FAIL.
4. Para riscv_top_tb correr hasta que termine (`run all`). Esperado: 58 instrucciones, 240 ciclos.
   El volcado queda en la carpeta de simulación (`volcado_memoria.txt`).

## Orden de lectura para defenderlo
alu -> imm_gen -> regfile -> regs/muxes -> mem -> control_unit -> riscv_top.
